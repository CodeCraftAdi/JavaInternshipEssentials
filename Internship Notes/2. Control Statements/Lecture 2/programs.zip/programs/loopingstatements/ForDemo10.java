package loopingstatements;

public class ForDemo10
{
    public static void main(String[] args)
    {
        for( ; ; );


//        for(; ;)
    }
}