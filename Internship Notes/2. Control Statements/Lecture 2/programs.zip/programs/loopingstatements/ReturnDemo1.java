package loopingstatements;

public class ReturnDemo1
{
    int sum()
    {
        int no1=10, no2=20;
        int res = no1+no2;
        System.out.println(res);

        return res;
    }
    public static void main(String[] args)
    {
        ReturnDemo1 obj = new ReturnDemo1();
        int result = obj.sum();
        System.out.println(result+100);
    }
}
