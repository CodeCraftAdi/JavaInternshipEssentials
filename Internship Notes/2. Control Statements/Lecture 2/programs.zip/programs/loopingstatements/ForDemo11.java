package loopingstatements;

public class ForDemo11
{
    public static void main(String[] args)
    {
//        for( ; false; )
//        {
//            System.out.println("hi");
//        }
    }
}