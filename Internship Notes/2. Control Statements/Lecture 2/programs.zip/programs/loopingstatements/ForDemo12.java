package loopingstatements;

public class ForDemo12
{
    public static void main(String[] args)
    {
        for( ; ; )
        {
            System.out.println("hi");
        }
//        System.out.println("hello");
    }
}