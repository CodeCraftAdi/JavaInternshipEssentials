package loopingstatements;

public class ForDemo14
{
    public static void main(String[] args)
    {
        for(int i=1,j=1; i<=5; j++)
        {
            System.out.println(i+" - "+j);
        }
    }
}