package loopingstatements;

public class ForDemo13
{
    public static void main(String[] args)
    {
        for(int i=1; i<=5; i++)
        {
            for(int j=1; j<=4; j++)
            {
                System.out.println(i+" - "+j);
            }
        }
    }
}