package loopingstatements;

public class ForDemo3
{
    public static void main(String[] args)
    {
//        int i=1;
//        for(i<=5; i++)
//        {
//            System.out.println(i);
//        }


        int i=1;
        for( ;i<=5; i++)
        {
            System.out.println(i);
        }
    }
}