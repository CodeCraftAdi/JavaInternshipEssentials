package loopingstatements;

public class ForDemo8
{
    public static void main(String[] args)
    {
        for( ; ; )
        {
            System.out.println("hi");
        }
    }
}