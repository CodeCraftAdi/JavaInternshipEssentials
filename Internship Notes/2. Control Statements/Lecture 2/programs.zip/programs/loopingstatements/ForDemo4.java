package loopingstatements;

public class ForDemo4
{
    public static void main(String[] args)
    {
        int i=1;
        for(System.out.println("hi"); i<=5; i++)
        {
            System.out.println(i);
        }
    }
}