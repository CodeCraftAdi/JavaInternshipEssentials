package loopingstatements;

public class ForDemo9
{
    public static void main(String[] args)
    {
//        if(true)
//            System.out.println("hiiii");
//
//        for(int i=1; i<=5; i++)
//            System.out.println(i);



        if(true)
            System.out.println("hiiii");
            System.out.println("hello");

        for(int i=1; i<=5; i++)
            System.out.println(i);
            System.out.println("hi");
    }
}