public class IfDemo1
{
    public static void main(String[] args)
    {
        int no1 = 10;

        if(no1 < 50)
        {
            System.out.println("Hello");
        }
    }
}
