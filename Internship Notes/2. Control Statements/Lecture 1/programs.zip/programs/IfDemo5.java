public class IfDemo5
{
    boolean m1()
    {
        return true;
    }
    public static void main(String[] args)
    {
        System.out.println("1");

        IfDemo5 obj = new IfDemo5();

        if( obj.m1() )
        {
            System.out.println("Hello");
        }

        System.out.println("2");
    }
}
