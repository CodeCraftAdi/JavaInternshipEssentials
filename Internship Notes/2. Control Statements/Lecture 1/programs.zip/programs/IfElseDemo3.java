public class IfElseDemo3
{
    public static void main(String[] args)
    {
        int no = 10;

        System.out.println("1");

        if( no>=0 )
        {
            System.out.println("Number is positive");
        }

//        System.out.println("2");

        else
        {
            System.out.println("Number is negative");
        }

        System.out.println("3");
    }
}
