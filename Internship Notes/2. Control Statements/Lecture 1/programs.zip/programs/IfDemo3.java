public class IfDemo3
{
    public static void main(String[] args)
    {
        System.out.println("1");

        if(false)
        {
            System.out.println("Hello");
        }

        System.out.println("2");
    }
}
