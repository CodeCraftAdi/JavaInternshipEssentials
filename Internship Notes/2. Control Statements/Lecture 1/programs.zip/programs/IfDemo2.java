public class IfDemo2
{
    public static void main(String[] args)
    {
        int no1 = 10;

        System.out.println("1");

        if(no1 > 50)
        {
            System.out.println("Hello");
        }

        System.out.println("2");
    }
}
