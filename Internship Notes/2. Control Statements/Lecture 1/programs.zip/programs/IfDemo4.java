public class IfDemo4
{
    static boolean m1()
    {
        return true;
    }
    public static void main(String[] args)
    {
        System.out.println("1");

        if( m1() )
        {
            System.out.println("Hello");
        }

        System.out.println("2");
    }
}
