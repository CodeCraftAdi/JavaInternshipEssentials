public class SwitchDemo3
{
    public static void main(String[] args)
    {
        int rollno = 102;

        switch(rollno)
        {
            case 101:
                System.out.println("Amit");
            case 102:
                System.out.println("Deepak");
            case 103:
                System.out.println("Kamal");
            default:
                System.out.println("Invalid rollno");
        }
    }
}