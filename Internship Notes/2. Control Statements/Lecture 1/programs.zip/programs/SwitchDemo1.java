public class SwitchDemo1
{
    public static void main(String[] args)
    {
        int rollno = 102;

        switch(rollno)
        {
            case 101:
                System.out.println("Amit");
                break;
            case 102:
                System.out.println("Deepak");
                break;
            case 103:
                System.out.println("Kamal");
                break;
            default:
                System.out.println("Invalid rollno");
                break;
        }
    }
}