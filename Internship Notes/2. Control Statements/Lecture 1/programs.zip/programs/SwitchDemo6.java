public class SwitchDemo6
{
    public static void main(String[] args)
    {
        int no = 111;

        switch(no)
        {
            case 'c':
                System.out.println("111");
                break;
            case 222:
                System.out.println("222");
                break;
            case 333:
                System.out.println("333");
                break;
        }
    }
}