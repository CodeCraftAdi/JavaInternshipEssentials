public class SwitchDemo5
{
    public static void main(String[] args)
    {
        char c = '+';

        switch(c)
        {
            case 111:
                System.out.println("+");
                break;
            case '-':
                System.out.println("-");
                break;
            case '*':
                System.out.println("*");
                break;
        }
    }
}