public class SwitchDemo2
{
    public static void main(String[] args)
    {
        String name = "Deepak";

        switch(name)
        {
            case "Amit":
                System.out.println("101");
                break;
            case "Deepak":
                System.out.println("102");
                break;
            case "Kamal":
                System.out.println("103");
                break;
            default:
                System.out.println("Invalid name");
                break;
        }
    }
}