public class SwitchDemo4
{
    public static void main(String[] args)
    {
        int rollno = 105;

        switch(rollno)
        {
            case 101:
                System.out.println("Amit");
                break;
            case 102:
                System.out.println("Deepak");
                break;
            case 103:
                System.out.println("Kamal");
                break;
        }
    }
}