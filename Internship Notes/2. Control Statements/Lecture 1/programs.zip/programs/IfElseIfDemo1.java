public class IfElseIfDemo1
{
    public static void main(String[] args)
    {
        int no = 10;

        if( no>=0 )
        {
            System.out.println("111");
        }
        else if( no>=10 )
        {
            System.out.println("222");
        }
        else if( no>=50 )
        {
            System.out.println("333");
        }
        else
        {
            System.out.println("444");
        }
    }
}