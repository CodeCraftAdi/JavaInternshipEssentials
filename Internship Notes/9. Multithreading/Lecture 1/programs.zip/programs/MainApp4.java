public class MainApp4
{
    public static void main(String[] args)
    {
//        Thread.currentThread().setName("deepak");
        System.out.println(100/0);
    }
}