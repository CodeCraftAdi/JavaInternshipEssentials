class MyThread2
{
    public void m1()
    {
        System.out.println("thread task performed");
    }
}
public class MainApp2
{
    public static void main(String[] args)
    {
        MyThread2 thread = new MyThread2();
        thread.m1();
    }
}