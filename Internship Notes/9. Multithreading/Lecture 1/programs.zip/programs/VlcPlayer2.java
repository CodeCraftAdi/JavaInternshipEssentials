class PlayVideo2 extends Thread
{
    public void run()
    {
        for(int i=1; i<=100; i++)
        {
            System.out.println("Video is playing");
        }
    }
}
class PlayAudio2 extends Thread
{
    public void run()
    {
        for(int i=1; i<=100; i++)
        {
            System.out.println("Audio is playing");
        }
    }
}
class PlayProgressBar2 extends Thread
{
    public void run()
    {
        for(int i=1; i<=100; i++)
        {
            System.out.println("Progress bar is started");
        }
    }
}
public class VlcPlayer2
{
    public static void main(String[] args)
    {
        PlayVideo2 t1 = new PlayVideo2();
        t1.start();

        PlayAudio2 t2 = new PlayAudio2();
        t2.start();

        PlayProgressBar2 t3 = new PlayProgressBar2();
        t3.start();
    }
}
