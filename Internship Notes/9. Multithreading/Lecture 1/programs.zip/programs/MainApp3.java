class MyThread3 implements Runnable
{
    @Override
    public void run()
    {
        System.out.println("Thread task by runnable interface...!!");
    }
}
public class MainApp3
{
    public static void main(String[] args)
    {
        MyThread3 mt = new MyThread3();
        Thread thread = new Thread(mt);
        thread.start();
    }
}