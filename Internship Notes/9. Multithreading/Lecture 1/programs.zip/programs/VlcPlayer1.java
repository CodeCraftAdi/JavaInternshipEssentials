class PlayVideo1
{
    void startVideo()
    {
        for(int i=1; i<=100; i++)
        {
            System.out.println("Video is playing");
        }
    }
}
class PlayAudio1
{
    void startAudio()
    {
        for(int i=1; i<=100; i++)
        {
            System.out.println("Audio is playing");
        }
    }
}
class PlayProgressBar1
{
    void startProgressBar()
    {
        for(int i=1; i<=100; i++)
        {
            System.out.println("Progress bar is started");
        }
    }
}
public class VlcPlayer1
{
    public static void main(String[] args)
    {
        PlayVideo1 t1 = new PlayVideo1();
        t1.startVideo();

        PlayAudio1 t2 = new PlayAudio1();
        t2.startAudio();

        PlayProgressBar1 t3 = new PlayProgressBar1();
        t3.startProgressBar();
    }
}
