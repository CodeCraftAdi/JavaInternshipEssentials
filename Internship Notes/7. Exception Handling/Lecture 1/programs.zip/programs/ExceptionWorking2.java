public class ExceptionWorking2
{
    void m1()
    {
        System.out.println("111");
        try
        {
            m2();
        }
        catch(Exception e)
        {
            System.out.println("You cannot divide by zero");
        }
    }

    void m2()
    {
        System.out.println(100/0);
        System.out.println("222");
    }

    public static void main(String[] args)
    {
        ExceptionWorking2 obj = new ExceptionWorking2();
        obj.m1();
    }
}