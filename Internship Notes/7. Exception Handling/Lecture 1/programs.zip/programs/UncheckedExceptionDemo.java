public class UncheckedExceptionDemo
{
    public static void main(String[] args)
    {
        int no1=100, no2=0;
        int res = no1/no2;
        System.out.println(res);
    }
}