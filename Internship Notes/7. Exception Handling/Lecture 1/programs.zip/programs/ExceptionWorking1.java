import java.io.FileInputStream;

public class ExceptionWorking1
{
    void m1() throws Exception
    {
        System.out.println("111");
        m2();
    }

    void m2() throws Exception
    {
        FileInputStream fis = new FileInputStream("---path---");
        System.out.println("222");
    }

    public static void main(String[] args) throws Exception
    {
        ExceptionWorking1 obj = new ExceptionWorking1();
        obj.m1();
    }
}