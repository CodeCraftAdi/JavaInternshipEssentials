public class TryCatchDemo1
{
    public static void main(String[] args)
    {
        try
        {
            int no1=100, no2=2;
            int res = no1/no2;
            System.out.println(res);
            System.out.println("success");
        }
        catch(Exception e)
        {
            System.out.println("111");
            System.out.println(e);
        }
    }
}
