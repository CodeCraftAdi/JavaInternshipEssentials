import java.io.FileInputStream;

public class ExceptionDemo3
{
    public static void main(String[] args)
    {
        try(
//                System.out.println("111");
                FileInputStream fis = new FileInputStream("c:/desktop/aaa.txt");
                )
        {
            System.out.println(100/0);
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            System.out.println(e);
            e.printStackTrace();
        }
    }
}










/*
import java.io.FileInputStream;

public class ExceptionDemo3
{
    public static void main(String[] args)
    {
        FileInputStream fis = null;
        try
        {
            fis = new FileInputStream("c:/desktop/aaa.txt");
            System.out.println(100/0);

        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            System.out.println(e);
            e.printStackTrace();
        }
        finally
        {
            try
            {
                fis.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}
*/