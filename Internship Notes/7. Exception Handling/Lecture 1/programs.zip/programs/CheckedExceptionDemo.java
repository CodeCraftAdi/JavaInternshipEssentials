import java.io.FileInputStream;

public class CheckedExceptionDemo
{
    public static void main(String[] args) //throws Exception
    {
//        FileInputStream fiss = new FileInputStream("path");

        try
        {
            FileInputStream fis = new FileInputStream("path");
        }
        catch(Exception e)
        {

        }
    }
}
