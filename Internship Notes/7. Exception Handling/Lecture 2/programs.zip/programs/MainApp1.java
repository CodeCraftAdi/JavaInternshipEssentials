public class MainApp1
{
    public static void main(String[] args)
    {
        int no1=100, no2=0;

        if(no2>0)
        {
            System.out.println(no1/no2);
        }
        else
        {
            System.out.println("No2 cannot be zero");
        }
    }
}
