import java.util.Scanner;

public class VotingApp2
{
    public void isEligibleToVote(int age) throws InvalidAgeException
    {
        if(age >= 18)
        {
            System.out.println("You are eligible to vote");
        }
        else
        {
            throw new InvalidAgeException("Sorry, you are not eligible to vote as your age is below 18");
        }
    }
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your age : ");
        int age = scanner.nextInt();

        try
        {
            new VotingApp2().isEligibleToVote(age);
        }
        catch(InvalidAgeException e)
        {
            e.printStackTrace();
        }

        System.out.println("voting finished successfully");
    }
}
