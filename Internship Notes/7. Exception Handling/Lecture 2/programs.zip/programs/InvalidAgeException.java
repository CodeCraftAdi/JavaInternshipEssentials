public class InvalidAgeException extends Exception
{
    public InvalidAgeException()
    {
        super();
    }
    public InvalidAgeException(String msg)
    {
        super(msg);
    }
}


/*public class InvalidAgeException extends RuntimeException
{
    public InvalidAgeException()
    {
        super();
    }
    public InvalidAgeException(String msg)
    {
        super(msg);
    }
}*/