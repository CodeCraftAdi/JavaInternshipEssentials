import java.util.Scanner;

public class VotingApp1
{
//    public void isEligibleToVote(int age)
//    {
//        if(age >= 18)
//        {
//            System.out.println("You are eligible to vote");
//        }
//        else
//        {
////            throw new InvalidAgeException("Sorry, you are not eligible to vote as your age is below 18");
//            throw new InvalidAgeException();
//        }
//    }
//    public static void main(String[] args)
//    {
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("Enter your age : ");
//        int age = scanner.nextInt();
//
//        try
//        {
//            new VotingApp1().isEligibleToVote(age);
//        }
//        catch(InvalidAgeException e)
//        {
////            System.out.println(e.getMessage());
//            System.out.println(e);
//        }
//
//        System.out.println("voting finished successfully");
//    }
}
