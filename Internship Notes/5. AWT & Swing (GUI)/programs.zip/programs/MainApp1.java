import javax.swing.*;

public class MainApp1
{
    public static void main(String[] args)
    {
        JFrame jFrame = new JFrame();
        jFrame.setSize(500, 300);
        jFrame.setVisible(true);
    }
}
