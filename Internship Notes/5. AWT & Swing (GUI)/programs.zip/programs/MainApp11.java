import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainApp11 implements ActionListener
{
    JFrame jFrame;
    JButton jButton;
    JTextField jTextField;

    public MainApp11()
    {
        jFrame = new JFrame("Login Frame");
//        jFrame.setTitle("My Frame");
        jFrame.setSize(600, 500);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //to close the frame
        jFrame.setLayout(null);                                 //to provide default layout and to use setBounds() method
        jFrame.setLocationRelativeTo(null);                     //to open the frame in center of screen

        JLabel jLabel = new JLabel("Enter Name : ");
        jLabel.setBounds(100, 100, 100, 40);
        jFrame.add(jLabel);

        jTextField = new JTextField();
        jTextField.setBounds(200, 100, 300, 40);
        jFrame.add(jTextField);

        jButton = new JButton("Click Me");
        jButton.setBounds(250, 200, 100, 50);
        jButton.addActionListener(this);
        jFrame.add(jButton);

        jFrame.setVisible(true);
    }
    public static void main(String[] args)
    {
        new MainApp11();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == jButton)
        {
            String name = jTextField.getText();
//            System.out.println("Hello : "+name);
            JOptionPane.showMessageDialog(jFrame, "Hello "+name);
            jTextField.setText("");
        }
    }
}
