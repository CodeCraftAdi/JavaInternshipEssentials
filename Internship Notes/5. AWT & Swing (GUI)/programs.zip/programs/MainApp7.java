import javax.swing.*;

public class MainApp7
{
    public void openFrame()
    {
        JFrame jFrame = new JFrame("Login Frame");
//        jFrame.setTitle("My Frame");
        jFrame.setSize(600, 500);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //to close the frame
        jFrame.setLayout(null);                                 //to provide default layout and to use setBounds() method
        jFrame.setLocationRelativeTo(null);                     //to open the frame in center of screen

        JLabel jLabel = new JLabel("Enter Name : ");
        jLabel.setBounds(100, 100, 100, 40);
        jFrame.add(jLabel);

        JTextField jTextField = new JTextField();
        jTextField.setBounds(200, 100, 300, 40);
        jFrame.add(jTextField);

        JButton jButton = new JButton("Click Me");
        jButton.setBounds(250, 200, 100, 50);
        jFrame.add(jButton);

        jFrame.setVisible(true);
    }
    public static void main(String[] args)
    {
//        MainApp7 obj = new MainApp7();
//        obj.openFrame();

        new MainApp7().openFrame();
    }
}
