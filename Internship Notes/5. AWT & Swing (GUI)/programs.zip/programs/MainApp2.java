import javax.swing.*;

public class MainApp2
{
    public static void main(String[] args)
    {
        JFrame jFrame = new JFrame();
        jFrame.setSize(500, 300);

        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jFrame.setVisible(true);
    }
}
