import javax.swing.*;

public class MainApp4
{
    public static void main(String[] args)
    {
        JFrame jFrame = new JFrame();
        jFrame.setSize(500, 300);

        JLabel jLabel = new JLabel("Enter Name : ");
        jFrame.add(jLabel);

        JTextField jTextField = new JTextField();   //not good because textfield will cover whole frame area and label will not be visible
        jFrame.add(jTextField);

        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jFrame.setVisible(true);
    }
}
