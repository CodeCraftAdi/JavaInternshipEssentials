import javax.swing.*;

public class MainApp5
{
    public static void main(String[] args)
    {
        JFrame jFrame = new JFrame("Login Frame");
//        jFrame.setTitle("My Frame");
        jFrame.setSize(600, 500);
        jFrame.setLayout(null);

        JLabel jLabel = new JLabel("Enter Name : ");
        jLabel.setBounds(100, 100, 100, 40);
        jFrame.add(jLabel);

        JTextField jTextField = new JTextField();
        jTextField.setBounds(200, 100, 300, 40);
        jFrame.add(jTextField);

        JButton jButton = new JButton("Click Me");
        jButton.setBounds(250, 200, 100, 50);
        jFrame.add(jButton);

        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jFrame.setVisible(true);
    }
}
