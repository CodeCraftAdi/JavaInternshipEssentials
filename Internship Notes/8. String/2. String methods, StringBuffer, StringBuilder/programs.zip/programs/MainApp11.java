public class MainApp11
{
    public static void main(String[] args)
    {
        StringBuffer stringBuffer = new StringBuffer("deepak");


        StringBuilder stringBuilder = new StringBuilder("deepak");

    }
}
