public class MainApp2
{
    public static void main(String[] args)
    {
        String name1 = "    am     it   ";

        if(name1.trim().isEmpty())
        {
            System.out.println("Name cannot be empty");
        }
        else if(name1.trim().length()<=5 || name1.trim().length()>=25)
        {
            System.out.println("Name should be of length 5 to 25 characters");
        }
        else
        {
            System.out.println("Valid name");
        }
    }
}
