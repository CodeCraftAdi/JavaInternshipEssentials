public class Test
{
    public static void main(String[] args)
    {
        String name1 = "deepak";
        System.out.println(name1.hashCode());

        String name2 = "amit";
        System.out.println(name2.hashCode());

        Integer no = 100;
        no.toString();
    }
}