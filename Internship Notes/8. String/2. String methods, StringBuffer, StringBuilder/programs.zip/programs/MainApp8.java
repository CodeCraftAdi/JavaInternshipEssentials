public class MainApp8
{
    public static void main(String[] args)
    {
        String name1 = "Deepak";

        System.out.println(name1.toLowerCase());
        System.out.println(name1.toUpperCase());
    }
}
