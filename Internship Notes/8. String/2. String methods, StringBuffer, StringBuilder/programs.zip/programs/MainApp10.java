public class MainApp10
{
    public static void main(String[] args)
    {
//        String name = "apple, mango, banana";
//        String[] str = name.split(", ");

//        String name = "apple mango banana";
//        String[] str = name.split(" ");

        String name = "apple-mango-banana";
        String[] str = name.split("-");

        for(String s : str)
        {
            System.out.println(s);
        }


//        String name = "applemangobanana";
//        for(int i=0; i<name.length(); i++)
//        {
//            System.out.println(name.charAt(i));
//        }
    }
}