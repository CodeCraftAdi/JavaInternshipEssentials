public class MainApp4
{
    public static void main(String[] args)
    {
        String name1 = "Deepak";

        System.out.println(name1+" Panwar");

        System.out.println(name1.concat(" Panwar"));
    }
}
