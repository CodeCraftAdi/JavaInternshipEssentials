public class MainApp9
{
    public static void main(String[] args)
    {
        int no = 100;

        System.out.println(String.valueOf(no));
    }
}
