import java.util.Scanner;

public class Task1
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your name : ");

        String name = scanner.next();

//        System.out.println("1 : "+name.substring(0,1).toUpperCase());
//        System.out.println("2 : "+name.substring(1));

        System.out.println("Name : "+name.substring(0,1).toUpperCase()+name.substring(1));
    }
}
