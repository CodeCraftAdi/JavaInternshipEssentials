public class MainApp5
{
    public static void main(String[] args)
    {
        String str = "this is demo";

        System.out.println(str.substring(3));

        System.out.println(str.substring(3,9));

        System.out.println(str.subSequence(3,9));
    }
}
