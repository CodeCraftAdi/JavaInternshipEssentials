public class MainApp3
{
    public static void main(String[] args)
    {
        String name1 = "deepak";
        String name2 = "dfepak";

        System.out.println(name1.equals(name2));

        System.out.println(name1.equalsIgnoreCase(name2));

        System.out.println(name1.compareTo(name2));

        System.out.println(name1.compareToIgnoreCase(name2));

        char ch = 'D';
        System.out.println( (int)ch );
    }
}
