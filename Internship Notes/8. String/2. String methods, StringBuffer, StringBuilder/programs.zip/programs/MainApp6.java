public class MainApp6
{
    public static void main(String[] args)
    {
        String name1 = "Deepak";

        System.out.println(name1.replace('e','z'));

        System.out.println(name1.replace("Dee", "Z"));

        System.out.println(name1.replaceFirst("e","z"));

        System.out.println(name1.replaceAll("e","z"));
    }
}
