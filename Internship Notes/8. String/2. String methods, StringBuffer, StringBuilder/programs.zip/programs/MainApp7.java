public class MainApp7
{
    public static void main(String[] args)
    {
        String name1 = "Deepak";

        System.out.println(name1.indexOf('p'));
        System.out.println(name1.indexOf('x'));

        System.out.println(name1.lastIndexOf('e'));

        System.out.println(name1.contains("pe"));

        System.out.println(name1.charAt(4));

        System.out.println(name1.endsWith("pk"));

        System.out.println(name1.startsWith("De"));

        System.out.println(name1.toLowerCase().startsWith("de"));
    }
}
