public class MainApp1
{
    public static void main(String[] args)
    {
        String name1 = new String();

        String name2 = new String("deepak");

        char[] ch = {'d','e','e','p','a','k'};
        String name3 = new String(ch);

        String name4 = "deepak";
    }
}
