class Test
{
    void m1()
    {
        System.out.println("m1() method in Test class");
    }
}
public class MainApp1 extends Test
{
    public static void main(String[] args)
    {
        MainApp1 obj = new MainApp1();
        obj.m1();
    }
}
