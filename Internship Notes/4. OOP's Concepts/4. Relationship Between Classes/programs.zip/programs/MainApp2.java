class Test2
{
    void m2()
    {
        System.out.println("m2() method in Test2 class");
    }
}
class Test22 extends Test2
{
    void m22()
    {
        System.out.println("m22() method in Test22 class");
    }
}
public class MainApp2 extends Test22
{
    void m()
    {
        System.out.println("m() method in MainApp2 method");
    }
    public static void main(String[] args)
    {
        Test2 obj1 = new Test2();
        obj1.m2();
//        obj1.m22();
//        obj1.m();

        Test22 obj2 = new Test22();
        obj2.m2();
        obj2.m22();
//        obj2.m();

        MainApp2 obj3 = new MainApp2();
        obj3.m2();
        obj3.m22();
        obj3.m();
    }
}
