class A
{
    void mA()
    {
        System.out.println("mA() method in class A");
    }
}
class B extends A
{
    void mB()
    {
        System.out.println("mB() method in class B");
    }
}
class C extends A
{
    void mC()
    {
        System.out.println("mC() method in class C");
    }
}
public class MainApp3
{
    public static void main(String[] args)
    {
        A obj1 = new A();
        obj1.mA();

        B obj2 = new B();
        obj2.mA();
        obj2.mB();

        C obj3 = new C();
        obj3.mA();
        obj3.mC();
    }
}
