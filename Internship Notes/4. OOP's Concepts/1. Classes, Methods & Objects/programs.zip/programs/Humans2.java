public class Humans2
{
    public void eat()
    {
        System.out.println("im eating");
    }

    public static void main(String[] args)
    {
        Humans2 deepak = new Humans2();
        deepak.eat();
        deepak.sleep();
    }

    public void sleep()
    {
        System.out.println("im sleeping");
    }
}
