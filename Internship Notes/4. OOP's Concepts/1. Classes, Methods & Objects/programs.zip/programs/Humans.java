public class Humans
{
    public void eat()
    {
        System.out.println("im eating");
    }
    public void sleep()
    {
        System.out.println("im sleeping");
    }

    public static void main(String[] args)
    {
        Humans deepak = new Humans();
        deepak.eat();
        deepak.sleep();
    }
}
