public class Humans3
{
    public void eat()
    {
        System.out.println("im eating");
    }

    public static void main(String[] args)
    {
        Humans3 deepak = new Humans3();
        deepak.sleep();
        deepak.eat();
    }

    public void sleep()
    {
        System.out.println("im sleeping");
    }
}