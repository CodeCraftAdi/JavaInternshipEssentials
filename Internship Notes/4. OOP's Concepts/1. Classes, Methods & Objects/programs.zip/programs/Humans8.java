public class Humans8
{
    int age = 28;   //this is not good way

    public void eat(String name)
    {
        System.out.println(name+" is eating");
    }

    public void isEligibleToVote(String name)
    {
        if(age>=18)
        {
            System.out.println("Yes, "+name+" is eligible to vote");
        }
        else
        {
            System.out.println("No, "+name+" is not eligible to vote");
        }
    }

    public static void main(String[] args)
    {
        Humans8 deepak = new Humans8();
        deepak.sleep();
        deepak.eat("Deepak");
        deepak.walking("Deepak", 6);
        deepak.isEligibleToVote("Deepak");

        Humans8 priya = new Humans8();
        priya.eat("Priya");
        priya.isEligibleToVote("Priya");

        Humans8 ravi = new Humans8();
        ravi.sleep();
        ravi.walking("Ravi", 11);
        ravi.isEligibleToVote("Ravi");
    }

    public void sleep()
    {
        System.out.println("I'm sleeping");
    }

    public void walking(String name, int distance)
    {
        System.out.println(name+" has walked "+distance+" km");
    }
}