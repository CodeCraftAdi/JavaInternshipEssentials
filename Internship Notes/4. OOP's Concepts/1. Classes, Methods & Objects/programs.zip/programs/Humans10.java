public class Humans10
{
    public void eat(String name)
    {
        System.out.println(name+" is eating");
    }

    public static void main(String[] args)
    {
        Humans11 deepak = new Humans11();
        deepak.sleep();
        deepak.eat("Deepak");

        Humans11 priya = new Humans11();
        priya.eat("Priya");

        Humans11 ravi = new Humans11();
        ravi.sleep();

        Birds b1 = new Birds();
        b1.fly();
    }

    public void sleep()
    {
        System.out.println("I'm sleeping");
    }
}
class Birds
{
    public void fly()
    {
        System.out.println("Im flying");
    }
}