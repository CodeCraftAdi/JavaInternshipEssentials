public class Humans7
{
    public void eat(String name)
    {
        System.out.println(name+" is eating");
    }

    public void isEligibleToVote(String name, int age)
    {
        if(age>=18)
        {
            System.out.println("Yes, "+name+" is eligible to vote");
        }
        else
        {
            System.out.println("No, "+name+" is not eligible to vote");
        }
    }

    public static void main(String[] args)
    {
        Humans7 deepak = new Humans7();
        deepak.sleep();
        deepak.eat("Deepak");
        deepak.walking("Deepak", 6);
        deepak.isEligibleToVote("Deepak", 28);

        Humans7 priya = new Humans7();
        priya.eat("Priya");
        priya.isEligibleToVote("Priya", 18);

        Humans7 ravi = new Humans7();
        ravi.sleep();
        ravi.walking("Ravi", 11);
        ravi.isEligibleToVote("Ravi", 16);
    }

    public void sleep()
    {
        System.out.println("I'm sleeping");
    }

    public void walking(String name, int distance)
    {
        System.out.println(name+" has walked "+distance+" km");
    }
}