public class Humans9
{
    int age;

    public void eat(String name)
    {
        System.out.println(name+" is eating");
    }

    public void isEligibleToVote(String name)
    {
        if(age>=18)
        {
            System.out.println("Yes, "+name+" is eligible to vote");
        }
        else
        {
            System.out.println("No, "+name+" is not eligible to vote");
        }
    }

    public static void main(String[] args)
    {
        Humans9 deepak = new Humans9();
        deepak.sleep();
        deepak.eat("Deepak");
        deepak.walking("Deepak", 6);
        deepak.age = 28;
        deepak.isEligibleToVote("Deepak");

        Humans9 priya = new Humans9();
        priya.eat("Priya");
        priya.age = 18;
        priya.isEligibleToVote("Priya");

        Humans9 ravi = new Humans9();
        ravi.sleep();
        ravi.walking("Ravi", 11);
        ravi.age = 17;
        ravi.isEligibleToVote("Ravi");
    }

    public void sleep()
    {
        System.out.println("I'm sleeping");
    }

    public void walking(String name, int distance)
    {
        System.out.println(name+" has walked "+distance+" km");
    }
}