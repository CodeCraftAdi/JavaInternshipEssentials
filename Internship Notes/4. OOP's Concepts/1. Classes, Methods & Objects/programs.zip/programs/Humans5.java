public class Humans5
{
    public void eat()
    {
        System.out.println("im eating");
    }

    public static void main(String[] args)
    {
        Humans5 deepak = new Humans5();
        deepak.sleep();
        deepak.eat();

        Humans5 priya = new Humans5();
        priya.eat();

        Humans5 ravi = new Humans5();
        ravi.sleep();
    }

    public void sleep()
    {
        System.out.println("im sleeping");
    }
}