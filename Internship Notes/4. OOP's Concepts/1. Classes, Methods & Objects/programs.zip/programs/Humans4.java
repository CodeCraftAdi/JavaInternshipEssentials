public class Humans4
{
    public void eat()
    {
        System.out.println("im eating");
    }

    public static void main(String[] args)
    {
        Humans4 deepak = new Humans4();
        deepak.sleep();
        deepak.eat();
        deepak.sleep();
        deepak.sleep();
        deepak.eat();
    }

    public void sleep()
    {
        System.out.println("im sleeping");
    }
}