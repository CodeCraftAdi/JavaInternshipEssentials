public class Humans6
{
    public void eat(String name)
    {
        System.out.println(name+" is eating");
    }

    public static void main(String[] args)
    {
        Humans6 deepak = new Humans6();
        deepak.sleep();
        deepak.eat("Deepak");
        deepak.walking("Deepak", 6);

        Humans6 priya = new Humans6();
        priya.eat("Priya");

        Humans6 ravi = new Humans6();
        ravi.sleep();
        ravi.walking("Ravi", 11);
    }

    public void sleep()
    {
        System.out.println("I'm sleeping");
    }

    public void walking(String name, int distance)
    {
        System.out.println(name+" has walked "+distance+" km");
    }
}