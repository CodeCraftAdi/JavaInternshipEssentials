public class MainApp
{
    void m1()
    {
        System.out.println("m1 method");
    }
    public static void main(String[] args)
    {
        MainApp obj = new MainApp();
        obj.m1();
    }
}