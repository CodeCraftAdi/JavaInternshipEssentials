public class MainApp1
{
    public static void main(String[] args)
    {
        Student deepak = new Student();
        Student ravi = new Student();

        deepak.name="Deepak";
        deepak.rollno=101;

        ravi.name = "Ravi";
        ravi.rollno = 102;

        deepak.display();
        ravi.display();
    }
}
class Student
{
    String name;
    int rollno;

    public void display()
    {
        System.out.println("Name : "+name);
        System.out.println("Rollno : "+rollno);
    }
}