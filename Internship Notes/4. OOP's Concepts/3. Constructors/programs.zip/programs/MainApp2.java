public class MainApp2
{
    public static void main(String[] args)
    {
        Student2 deepak = new Student2("Deepak", 101);
        Student2 ravi = new Student2("Ravi", 102);

        deepak.display();
        ravi.display();
    }
}
class Student2
{
    String name;
    int rollno;

    Student2(String name1, int rollno1)
    {
        name = name1;
        rollno = rollno1;
    }

    public void display()
    {
        System.out.println("Name : "+name);
        System.out.println("Rollno : "+rollno);
    }
}