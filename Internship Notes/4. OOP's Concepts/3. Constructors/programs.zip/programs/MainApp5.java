public class MainApp5
{
    public MainApp5(int no)
    {
        System.out.println("No : "+no);
    }

    public static void main(String[] args)
    {
//        MainApp4 obj = new MainApp4(100);
        new MainApp5(100);
    }
}