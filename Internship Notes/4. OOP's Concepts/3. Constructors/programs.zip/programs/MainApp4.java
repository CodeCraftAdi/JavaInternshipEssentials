public class MainApp4
{
    public MainApp4()
    {
        System.out.println("This is 0 argument constructor");
    }

    public static void main(String[] args)
    {
//        MainApp4 obj = new MainApp4();
        new MainApp4();
    }
}