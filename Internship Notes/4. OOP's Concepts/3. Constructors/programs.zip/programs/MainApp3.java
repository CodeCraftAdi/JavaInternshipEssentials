public class MainApp3
{
    void m1()
    {
        System.out.println("m1 method");
    }
    public static void main(String[] args)
    {
        MainApp3 obj = new MainApp3();
        obj.m1();
    }
}