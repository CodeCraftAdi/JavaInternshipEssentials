class Student
{
    public Student() {}

    private int rollno;
    private String name;

    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    void display()
    {
        System.out.println("Rollno : "+rollno);
        System.out.println("Name : "+name);
    }
}
public class MainApp
{
    public static void main(String[] args)
    {
        Student std1 = new Student();
        std1.setName("Deepak");
        std1.setRollno(101);
        std1.display();

        Student std2 = new Student();
        std2.setName("Ravi");
        std2.setRollno(102);
        std2.display();
    }
}
