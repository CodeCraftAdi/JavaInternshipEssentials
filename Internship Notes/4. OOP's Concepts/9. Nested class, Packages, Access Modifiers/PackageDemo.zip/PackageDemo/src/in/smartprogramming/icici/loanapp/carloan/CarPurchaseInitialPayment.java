package in.smartprogramming.icici.loanapp.carloan;

public class CarPurchaseInitialPayment
{
    //1 lakh rs
}
