package in.smartprogramming.icici.loanapp.educationloan;

public class EducationLoanTerms
{
    //----------
}
