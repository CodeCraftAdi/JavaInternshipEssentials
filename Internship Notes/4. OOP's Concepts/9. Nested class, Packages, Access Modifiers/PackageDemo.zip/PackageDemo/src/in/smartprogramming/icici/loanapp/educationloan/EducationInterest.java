package in.smartprogramming.icici.loanapp.educationloan;

public class EducationInterest
{
    // 7.4%
}
