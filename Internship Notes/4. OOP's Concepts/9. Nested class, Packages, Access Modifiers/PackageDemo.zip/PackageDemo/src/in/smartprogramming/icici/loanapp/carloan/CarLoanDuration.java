package in.smartprogramming.icici.loanapp.carloan;

public class CarLoanDuration {
}
