package p2;

//import p1.Test1;
//import p1.Test2;

import p1.*;

public class Test3 extends Test1
{
    public static void main(String[] args)
    {
        Test3 obj1 = new Test3();
        obj1.m1();

        Test2 obj2 = new Test2();
        obj2.m2();
    }
}
