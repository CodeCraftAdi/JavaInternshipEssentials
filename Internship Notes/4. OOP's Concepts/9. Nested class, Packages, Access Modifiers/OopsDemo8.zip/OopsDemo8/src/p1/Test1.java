package p1;

public class Test1
{
    private void m1()
    {
        System.out.println("m1()..........");
    }
}