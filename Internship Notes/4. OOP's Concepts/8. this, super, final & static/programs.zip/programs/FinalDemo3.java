class Test
{

}
final class Aa3 extends Test
{

}
public class FinalDemo3 // extends Aa3
{

}