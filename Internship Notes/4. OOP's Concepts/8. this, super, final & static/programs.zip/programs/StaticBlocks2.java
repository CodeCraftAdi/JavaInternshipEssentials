public class StaticBlocks2
{
    static
    {
        System.out.println("111");
    }

    public static void main(String[] args)
    {

    }

    static
    {
        System.out.println("222");
    }
}
