public class FinalDemo1
{
    public static void main(String[] args)
    {
//        final int no = 10;
//        no = no+20;
//        System.out.println(no);


        final int no = 10;
        int res = no+20;
        System.out.println(res);
    }
}
