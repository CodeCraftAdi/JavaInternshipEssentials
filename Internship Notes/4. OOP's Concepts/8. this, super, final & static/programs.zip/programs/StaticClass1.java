public class StaticClass1
{
    static class A
    {

    }
}
//static class Aaa
//{
//
//}