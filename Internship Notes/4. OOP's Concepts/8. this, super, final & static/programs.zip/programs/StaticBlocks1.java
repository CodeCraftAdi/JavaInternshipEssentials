public class StaticBlocks1
{
    static
    {
        System.out.println("1111");
    }

    public static void main(String[] args)
    {
        System.out.println("main method");
    }
}
