interface i2
{
    public void m1();
    void m2();

    default void m3()
    {

    }

    static void m4()
    {

    }

    private static void m5()
    {

    }
}
class A2 implements i2
{
    public void m1()
    {

    }
    public void m2()
    {

    }
}
public class MainApp2
{
    public static void main(String[] args)
    {
        i2 obj = new A2();
        obj.m1();
        obj.m2();
    }
}
