class A3
{
    public void m1()
    {

    }
}
class B3 extends A3
{
    public void m1()
    {

    }
}
public class MainApp3
{
}
