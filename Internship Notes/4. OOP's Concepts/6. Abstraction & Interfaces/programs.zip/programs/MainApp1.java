class Test
{

}
abstract class A1 extends Test
{
    A1()
    {
        System.out.println("A1 constructor called");
    }
    void m1()
    {
        System.out.println("hi");
    }
    abstract void m2();

    abstract void m2(String str);

    void m2(int a)
    {

    }
}
class B1 extends A1
{
    B1(int no)
    {

    }
    void m2()
    {
        System.out.println("1111");
    }
    void m2(String str)
    {

    }
}
public class MainApp1
{
    public static void main(String[] args)
    {
//        A1 obj1 = new A1();

//        new A1();

        A1 obj2 = new B1(10);
        obj2.m1();
        obj2.m2();
    }
}
