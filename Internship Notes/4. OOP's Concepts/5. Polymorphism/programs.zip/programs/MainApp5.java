public class MainApp5
{
    MainApp5()
    {
        System.out.println("1111");
    }
    MainApp5(int no)
    {
        System.out.println("22222");
    }
}
