class A
{
    void mA()
    {
        System.out.println("mA() method");
    }
}
class B extends A
{
    void mB()
    {
        System.out.println("mB() method");
    }
}
public class MainApp
{
    public static void main(String[] args)
    {
        A obj1 = new A();
        obj1.mA();

        B obj2 = new B();
        obj2.mA();
        obj2.mB();

        A obj3 = new B();
        obj3.mA();

//        B obj4 = new A();
    }
}
