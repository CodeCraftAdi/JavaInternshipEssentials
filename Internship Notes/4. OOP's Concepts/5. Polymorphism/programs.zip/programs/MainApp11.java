class A11
{
    int m1()
    {
        System.out.println("1111");
        return 0;
    }
}
public class MainApp11 extends A11
{
    int m1()
    {
        System.out.println("2222");
        return 0;
    }
    public static void main(String[] args)
    {
        A11 obj = new MainApp11();
        obj.m1();
    }
}