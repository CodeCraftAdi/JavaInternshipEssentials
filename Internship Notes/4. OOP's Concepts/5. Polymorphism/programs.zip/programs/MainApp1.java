class A1
{
    void m1()
    {
        System.out.println("m1() method in A1 class");
    }

    void m1(int no)
    {
        System.out.println("m1(no) method in A1 class");
    }
}
public class MainApp1
{
    public static void main(String[] args)
    {
        A1 obj = new A1();
        obj.m1();
        obj.m1(10);
    }
}
