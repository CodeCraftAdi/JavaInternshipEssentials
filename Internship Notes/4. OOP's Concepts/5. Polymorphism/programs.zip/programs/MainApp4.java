public class MainApp4
{
    public static void main(String[] args)
    {

    }

    public static void main()
    {

    }
}
