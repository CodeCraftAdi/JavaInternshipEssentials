public class MainApp6
{
//    String m6()
//    {
//        return null;
//    }
//
//    int m6()
//    {
//        return 0;
//    }
}
