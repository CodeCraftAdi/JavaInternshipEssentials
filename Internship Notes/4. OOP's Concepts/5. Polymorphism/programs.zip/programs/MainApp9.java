class Parent
{
    void marriage()
    {
        System.out.println("Arrange marriage");
    }
}
class Child extends Parent
{
    void marriage()
    {
        System.out.println("Love marriage");
    }
}
public class MainApp9
{
    public static void main(String[] args)
    {
        Parent obj = new Child();
        obj.marriage();
    }
}
