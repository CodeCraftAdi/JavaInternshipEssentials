class WishInAmerica
{
    void wish()
    {
        System.out.println("Hello");
    }
}
class WishInIndia extends WishInAmerica
{
    void wish()
    {
        System.out.println("Namaste");
    }
}
public class MainApp8
{
    public static void main(String[] args)
    {
        WishInAmerica obj = new WishInIndia();
        obj.wish();
    }
}
