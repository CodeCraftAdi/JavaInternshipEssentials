class A2
{
    void m1(String str)
    {
        System.out.println("m1() method in A1 class");
    }

    void m1(int no)
    {
        System.out.println("m1(no) method in A1 class");
    }
}
public class MainApp2
{
    public static void main(String[] args)
    {
        A2 obj = new A2();
        obj.m1("deepak");
        obj.m1(10);
    }
}
