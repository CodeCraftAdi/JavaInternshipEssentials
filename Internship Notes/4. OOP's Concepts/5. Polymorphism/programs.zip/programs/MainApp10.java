import java.util.ArrayList;

class A10 extends ArrayList
{
    public int size()
    {
        return 0;
    }
}
public class MainApp10
{
}
