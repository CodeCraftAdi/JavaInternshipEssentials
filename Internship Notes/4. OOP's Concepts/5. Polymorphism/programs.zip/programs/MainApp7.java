class A7
{
    void m1()
    {
        System.out.println("m1() method in A7 class");
    }
}
class B7 extends A7
{
    void m1()
    {
        System.out.println("m1() method in B7 class");
    }
}
public class MainApp7
{
    public static void main(String[] args)
    {
//        A7 obj1 = new A7();
//        obj1.m1();
//
//        B7 obj2 = new B7();
//        obj2.m1();

        A7 obj3 = new B7();
        obj3.m1();
    }
}
