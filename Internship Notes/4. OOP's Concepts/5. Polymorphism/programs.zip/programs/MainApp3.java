class A3
{
    void m1(String str, int no)
    {
        System.out.println("m1() method in A1 class");
    }

    void m1(int no, String str)
    {
        System.out.println("m1(no) method in A1 class");
    }
}
public class MainApp3
{
    public static void main(String[] args)
    {
        A3 obj = new A3();
        obj.m1("deepak", 10);
        obj.m1(20, "amit");
    }
}
class Cal
{
    int sum(int no1, int no2)
    {
        return no1+no2;
    }

    int sum(int no1, int no2, int no3)
    {
        return no1+no2+no3;
    }
}